package com.cognizant.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.model.Movie;
import com.cognizant.repository.MovieRepository;
import com.cognizant.service.MovieService;

import lombok.extern.java.Log;
import lombok.extern.log4j.Log4j2;
import lombok.extern.slf4j.Slf4j;
@Slf4j
@Log
@Log4j2
@RestController
@RequestMapping("/movie")
public class MovieController {
	@Autowired
	private MovieService service;
	@Autowired
	MovieRepository repository;
	@GetMapping("/adminlist")
	public List<Movie> adminMovieList() {
		log.info("START");
		log.info("END");
		return repository.findAll();
	}

	@GetMapping("/customerlist")
	public List<Movie> customerMovieList() {
		log.info("START");
		log.info("END");
		return service.CustomerMovieList();
	}

	@PutMapping("/adminlist")
	public List<Movie> editMovie(@RequestBody Movie movie) {
		log.info("START");
		log.info("END");
		return service.modifyMovie(movie);
	}

	@GetMapping("/adminlist/{id}")
	public Movie getMovie(@PathVariable long id) {
		log.info("START");

		Optional<Movie> m = repository.findById(id);
		if (m.isPresent()) {
			log.debug("Movie: {}", m);
			log.info("END");
			return m.get();
		} else {
			log.info("END");
			log.info("Movie not found");
		}
		log.info("END");
		return null;

	}
}
