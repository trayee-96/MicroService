package com.cognizant.service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cognizant.model.Movie;
import com.cognizant.repository.MovieRepository;
import com.cognizant.util.DateUtil;

import lombok.extern.java.Log;

@Service
@Log
public class MovieService {
@Autowired
MovieRepository repository;
@Transactional
public Movie Addmovie(Movie item) {
	log.info("START");
	log.info("END");
	return repository.save(item);
}
public List<Movie> modifyMovie(Movie movie) {
	log.info("START");
	List<Movie> list = repository.findAll();
	for (Movie mv : list) {
		if (movie.getId() == mv.getId()) {
			mv.setTitle(movie.getTitle());
			mv.setActive(movie.isActive());
			mv.setBoxOffice(movie.getBoxOffice());
			mv.setDateOfLaunch(movie.getDateOfLaunch());
			mv.setGenre(movie.getGenre());
			mv.setHasTeaser(movie.isHasTeaser());
			 repository.save(mv);
			log.info("END");
			break;
		}
	}
	return list;
}

public List<Movie> CustomerMovieList() {
	log.info("START");
	List<Movie> list = new ArrayList<Movie>();
	List<Movie> customerList = new ArrayList<Movie>();
	LocalDateTime localDateTime = LocalDateTime.now();
	String format = DateTimeFormatter.ofPattern("dd/mm/yyyy", Locale.ENGLISH).format(localDateTime);
	Date currentSystemDate = DateUtil.convertToDate(format);
	list =repository.findAll();
	for (Movie mv : list) {
		if ((mv.isActive() == true) && (mv.getDateOfLaunch().compareTo(currentSystemDate) < 0)) {
			customerList.add(mv);

		}
	}
	log.info("END");
	return customerList;
}
}
