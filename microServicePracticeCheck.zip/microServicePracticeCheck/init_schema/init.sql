DROP SCHEMA IF EXISTS docker_db;
create schema docker_db;
use docker_db

create table menuitems(id long,name varchar(120), price float,active boolean, dateoflaunch date,category varchar(120), freedelivery boolean);
create table movielist(id long,title varchar(120), boxoffice varchar(120),active boolean, dateoflaunch date,genre varchar(120), hasteaser boolean);

insert into menuitem(id,name,price,actv,dateoflaunch,category,freedelivery)
values
(100,"Sandwich",10000,true,"2017-12-17","maincourse",true),
(101,"Burger",10000,true,"2017-12-17","maincourse",true),
(102,"Pizza",10000,true,"2017-12-17","maincourse",true),
(103,"Fries",10000,true,"2017-12-17","starter",true),
(104,"Brownies",10000,true,"2017-12-17","starter",true);
insert into movielist(id,title,boxoffice,active,dateoflaunch,genre,hasteaser)
values
(100,"You","123,1234,123",true,"2017-12-17","Thriller",true),
(101,"Breathe","123,1234,123",true,"2017-12-17","Suspense",true),
(102,"Notebook","123,1234,123",true,"2017-12-17","Romance",true),
(103,"Avtar","123,1234,123",true,"2017-12-17","Adventure",true),
(104,"Bates Motel","123,1234,123",true,"2017-12-17","Mystry",true);