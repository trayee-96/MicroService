package com.cognizant.service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.model.MenuItem;
import com.cognizant.repository.MenuItemRepository;

import lombok.extern.java.Log;

@Service
@Log
public class MenuItemService {
@Autowired
MenuItemRepository repository;
@Transactional
public MenuItem Addmovie(MenuItem item) {
	log.info("START");
	log.info("END");
	return repository.save(item);
	
}
@Transactional
public List<MenuItem> getAll() {
	log.info("START");
	log.info("END");
	return repository.findAll();
}
@Transactional
public void modifyMenuById(long id,MenuItem item) {
	log.info("START");
	Optional<MenuItem> menu=repository.findById(id);
	if(menu.isPresent()) {
		MenuItem m=menu.get();
		m.setCategory(item.getCategory());
		m.setName(item.getName());
		m.setPrice(item.getPrice());
		m.setDateOfLaunch(item.getDateOfLaunch());
		repository.save(m);
	}
	else
		System.out.println("Menu with id: "+id+" is not present");
	log.info("END");
}
@Transactional
public List<MenuItem> getByCustomer(){
	log.info("START");
	log.info("END");
	return repository.findByActiveTrueAndDateOfLaunchBefore(new Date());
}

}
