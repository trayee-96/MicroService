package com.cognizant.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.cognizant.model.Marks;

@FeignClient(name = "marks-service") // url = "http://localhost:8084/marks")
public interface GradeServiceclient {
	@GetMapping("/marks/{id}")
	public Marks getAllMarks(@PathVariable("id") int id);
}
