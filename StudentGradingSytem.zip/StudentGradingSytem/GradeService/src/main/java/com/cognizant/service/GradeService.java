package com.cognizant.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.client.GradeServiceclient;
import com.cognizant.client.StudentClient;
import com.cognizant.model.Marks;
import com.cognizant.model.ShowMarksDetails;
import com.cognizant.model.Student;

import lombok.extern.java.Log;
@Service
@Log
public class GradeService {
	@Autowired
	private GradeServiceclient client;
	@Autowired
	private StudentClient clientStudent;
public ShowMarksDetails calculateGrade(int id) {
	
	Student s=clientStudent.getStudent(id);
	Marks m = client.getAllMarks(id);
	log.info("START");
	double sum= m.getBengali()+m.getChemistry()+m.getEnglish()+m.getMath()+m.getPhysics();
	double avg=sum/5;
	String grade="";
	if(avg<=30)
		grade= "Fail";
	else if(avg>=31 && avg<=40)
		grade= "D";
	else if(avg>=41 && avg<=50)
		grade= "C";
	else if(avg>=51 && avg<=60)
		grade= "B";
	else if(avg>=61 && avg<=70)
		grade= "A";
	else if(avg>=71 && avg<=80)
		grade= "A++";
	else 
		grade= "AA";
	ShowMarksDetails smd=new ShowMarksDetails(s.getName(),m.getBengali(),m.getEnglish(),m.getPhysics(),m.getChemistry(),m.getMath(),grade);
	
	return smd;
}
}
