package com.cognizant.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ShowMarksDetails {
	private String name;
	private double bengali;
	private double english;
	private double physics;
	private double chemistry;
	private double math;
	private String grade;
	public ShowMarksDetails(String name, double bengali, double english, double physics, double chemistry, double math,
			String grade) {
		super();
		this.name = name;
		this.bengali = bengali;
		this.english = english;
		this.physics = physics;
		this.chemistry = chemistry;
		this.math = math;
		this.grade = grade;
	}
	
}
