package com.cognizant.exception;

public class NoMarksRecordFoundException extends Exception {
	private static final long serialVersionUID = 1L;

	public NoMarksRecordFoundException() {
	super("Marks for this student is Not Found");
}
}
