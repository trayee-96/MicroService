package com.cognizant.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Marks {
	private int id;
	private double bengali;
	private double english;
	private double physics;
	private double chemistry;
	private double math;
}
