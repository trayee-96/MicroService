package com.cognizant.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.cognizant.model.Student;

@FeignClient(name="student-service")
public interface StudentClient {
@GetMapping("/student/{uid}")
Student getStudent(@PathVariable("uid") int uid);
}
