package com.cognizant.controller;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;

import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import com.cognizant.model.ShowMarksDetails;
import com.cognizant.service.GradeService;
@SpringBootTest
@AutoConfigureMockMvc
class GradeControllerTest {
	@MockBean
	private GradeService service;
	@Autowired
	MockMvc mvc;
	private ShowMarksDetails grade;
	
@BeforeEach
void setUp() {
	grade=new ShowMarksDetails("ani",90,76,85,48,65,"A+");
	
}
	@Test
	void testGetGrade() throws Exception{
	when(service.calculateGrade(1)).thenReturn(grade);
	mvc.perform(get("/grade/1")).equals(grade);
	}

}
 