package com.cognizant.model;

import java.util.Map;

import javax.persistence.Entity;

public class Marks {
	private int id;
	private double bengali;
	private double english;
	private double physics;
	private double chemistry;
	private double math;
}
