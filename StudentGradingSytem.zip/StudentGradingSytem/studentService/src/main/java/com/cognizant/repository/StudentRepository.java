package com.cognizant.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cognizant.model.Student;
@Repository
public interface StudentRepository  extends JpaRepository<Student, Integer>{
	Optional<Student> findById(String id);

	//void delete(Optional<Student> m);
	List<Student> findAll();
	
}
