package com.cognizant.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.exception.StudentNotFoundException;
import com.cognizant.model.Student;
import com.cognizant.repository.StudentRepository;

import lombok.extern.java.Log;

@Service
@Log
public class StudentService {
	@Autowired
	StudentRepository repository;
    @Transactional
	public List<Student> getAllStudents() {
		log.info("START");
		log.info("END");
		return repository.findAll();
	}
	@Transactional
	public Optional<Student> findById(int id) {
		log.info("START");
		log.info("END");
		return repository.findById(id);
	}

	@Transactional
	public String save(Student std) {
		log.info("START");
		log.info("END");
		repository.save(std);
		return "Success";
	}

	@Transactional
	public String deleteById(int id) {
		log.info("START");
		log.info("END");
		repository.deleteById(id);
		return "Deleted";
	}
	public String update(int id, Student student) {
		log.info("START");
		Optional<Student> m = repository.findById(id);
		if(m.isPresent()) {
			Student m1 = m.get();
			student.setId(m1.getId());
			repository.save(student);
			log.info("END");
			return "Successfully Updated";
		}
		log.info("END");
		return "The movie with id "+id+" is not found.";
	}
	/*public String deleteStudent(int stId) throws StudentNotFoundException{
		log.info("START");
		Optional<Student> m = repository.findById(stId);
		if(m.isPresent()) {
			Student m1 = m.get();
			repository.delete(m);
		}
		else throw new StudentNotFoundException("Student with this Id doesn't exist");
		return "SUCCESS";
		}*/
		
}
