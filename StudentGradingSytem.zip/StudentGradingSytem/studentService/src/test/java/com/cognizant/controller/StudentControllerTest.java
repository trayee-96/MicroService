package com.cognizant.controller;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import com.cognizant.model.Student;
import com.cognizant.service.StudentService;
import com.fasterxml.jackson.databind.ObjectMapper;
@SpringBootTest
@AutoConfigureMockMvc
class StudentControllerTest {
	@MockBean
	StudentService service;
	@Autowired
	MockMvc mvc;
	
	@BeforeEach
	public void init() {
		//st=new Student(1,"blr","trayee");
	}
	@Test
	void testGetAll() throws Exception {
		List<Student> student=new ArrayList<>();
		student.add(new Student(6,"blr","Parag"));
		when(service.getAllStudents()).thenReturn(student);
		mvc.perform(get("/student/all")).equals(student);
	}

	@Test
	void testGetStudentById() throws Exception{
		Optional<Student> stu;
		stu= Optional.of(new Student(10,"blr","Parag"));
		when(service.findById(10)).thenReturn(stu);
		mvc.perform(get("/student/10")).equals(stu);
	}

	@Test
	void testAddStudent() throws Exception {
		Student m=new Student(1,"chn","Ankita");
		when(service.save(m)).thenReturn("Success");
		mvc.perform(post("/student/add")
				.contentType(MediaType.APPLICATION_JSON)
				.content("{"+
						"\"id\":\"1\",\n"+
						"\"name\":\"chn\",\n"+
						"\"location\":\"Ankita\",\n"+
						"}"));
		//andExpect(status().isOk());
	}

	@Test
	void testEdit() throws Exception {
		Student user=new Student(17, "Delhi", "Ashutosh");
		when(service.update(17, user)).thenReturn("Successfully Updated");
		ObjectMapper mapper = new ObjectMapper();
		String str = mapper.writeValueAsString(user);
		mvc.perform(put("/student/update/17").
				contentType(org.springframework.http.MediaType.APPLICATION_JSON).content(str)).
		andExpect(status().isOk());
	}

	@Test
	void testDeleteStudent() throws Exception{
		when(service.deleteById(1)).thenReturn("Deleted");
		mvc.perform(delete("/student/delete/1")).andExpect(status().isOk());
	}

}
