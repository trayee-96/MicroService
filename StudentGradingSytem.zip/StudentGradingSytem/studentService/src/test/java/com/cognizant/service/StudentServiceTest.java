package com.cognizant.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.cognizant.exception.StudentNotFoundException;
import com.cognizant.model.Student;
import com.cognizant.repository.StudentRepository;
@SpringBootTest
class StudentServiceTest {
	@MockBean
	private StudentRepository repository;
	@Autowired
	private StudentService service;

	@Test
	void testGetAllStudents() throws Exception{
		List<Student> student=new ArrayList<>();
		student.add(new Student(1,"abc","cde"));
		when(repository.findAll()).thenReturn(student);
		assertEquals(student,service.getAllStudents());
	}

	@Test
	void testFindById() throws StudentNotFoundException{
		Optional<Student> marks=Optional.of(new Student(2,"ani","kolkata"));
		when(repository.findById(2)).thenReturn(marks);
		Optional<Student> m=service.findById(2);
		assertThat(m).isNotNull();
}

	@Test
	void testSave() throws Exception{
		Student std=new Student(3,"Satish","Kolkata");
		when(repository.save(std)).thenReturn(std);
		assertEquals("Success",service.save(std));
	}

	@Test
	void testDeleteById() throws StudentNotFoundException{
		 Student su = new Student(15,"delhi","gita");
		 when(repository.findById(15)).thenReturn(Optional.of(su));
		 assertEquals("Deleted",service.deleteById(15));
		 //verify(repository,times(1)).delete(su);
	}
	@Test
	 void testDeleteById1()throws StudentNotFoundException{

	 when(repository.findById(1)).thenReturn(Optional.empty());

	 }

	@Test
	void testUpdate() throws StudentNotFoundException{
		Student su = new Student(13,"delhi","Sanket");
		 when(repository.findById(13)).thenReturn(Optional.of(su));
		 assertEquals("Successfully Updated", service.update(13, su));
	}

}
