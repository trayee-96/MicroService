package com.cognizant.controller;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import com.cognizant.model.Marks;
import com.cognizant.service.MarksService;
@SpringBootTest
@AutoConfigureMockMvc
class MarksControllerTest {
	@MockBean
	MarksService service;
	@Autowired
	MockMvc mvc;
	private Optional<Marks> marks;
	@BeforeEach
	public void init() {
		marks = Optional.of(new Marks(14,54,62,74,81,91));
	}

	@Test
	void testGetAll() throws Exception {
		//fail("Not yet implemented");
		List<Marks> m =new ArrayList<>();
		m.add(new Marks(24,84,72,74,81,91));
		when(service.getAllMarks()).thenReturn(m);
		mvc.perform(get("/marks/all")).equals(m);
	}

	@Test
	void testGetMarksById() throws Exception {
		when(service.findById(14)).thenReturn(marks);
		mvc.perform(get("/marks/14")).equals(marks);
	}

	@Test
	void testAddMarks() throws Exception{
		Marks m=new Marks(14,54,62,74,81,91);
		when(service.save(m)).thenReturn("Success");
		mvc.perform(post("/marks/add")
				.contentType(MediaType.APPLICATION_JSON)
				.content("{"+
						"\"id\":\"14\",\n"+
						"\"bengali\":\"54\",\n"+
						"\"english\":\"62\",\n"+
						"\"physics\":\"74\",\n"
						+"\"chemistry\":\"81\",\n"+
						"\"math\":\"91\",\n"+
						"}"));
		//andExpect(status().isOk());
	}
	

}
