package com.cognizant.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.cognizant.model.Marks;
import com.cognizant.repository.MarksRepository;

@SpringBootTest
class MarksServiceTest {
	@MockBean
	private MarksRepository repository;
	@Autowired
	private MarksService service;
	@Test
	void testGetAllMarks() {
		List<Marks> marks = new ArrayList<>();

		 marks.add(new Marks(15,45,87,65,41,25));

		 when(repository.findAll()).thenReturn(marks);

		 assertEquals(marks, service.getAllMarks());
	}

	@Test
	void testFindById() {
		int id=1;
		Optional<Marks> marks=Optional.of(new Marks(1,85,87,45,41,25));
		when(repository.findById(1)).thenReturn(marks);
		Optional<Marks> m=service.findById(1);
		assertThat(m).isNotNull();
	}

	@Test
	void testSave() {
		int id=10;
		Marks marks=new Marks(10,85,87,45,41,25);
		when(repository.save(marks)).thenReturn(marks);
		assertEquals("Success",service.save(marks));
	}

}
