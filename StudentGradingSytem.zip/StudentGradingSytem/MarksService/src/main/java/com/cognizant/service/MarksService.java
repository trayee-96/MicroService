package com.cognizant.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.model.Marks;
import com.cognizant.repository.MarksRepository;

import lombok.extern.java.Log;

@Service
@Log
public class MarksService {
	@Autowired
	MarksRepository repository;
	@Transactional
	public List<Marks> getAllMarks() {
		log.info("START");
		log.info("END");
		return repository.findAll();
	}
	@Transactional
	public Optional<Marks> findById(int id) {
		log.info("START");
		log.info("END");
		return repository.findById(id);
	}
	@Transactional
	public String save(Marks m) {
		log.info("START");
		log.info("END");
		repository.save(m);
		return "Success";
	}
}
