package com.cognizant.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Table(name="marks")
public class Marks {
	@Id
	@Column(name="st_id")
	private int id;
	@Column(name="bengali")
	private double bengali;
	@Column(name="english")
	private double english;
	@Column(name="physics")
	private double physics;
	@Column(name="chemistry")
	private double chemistry;
	@Column(name="maths")
	private double math;
}
