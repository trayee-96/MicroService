package com.cognizant.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.exception.MarksNotFoundException;
import com.cognizant.model.Marks;
import com.cognizant.service.MarksService;

import lombok.extern.java.Log;

@RestController
@RequestMapping("/marks")
@Log
public class MarksController {
	@Autowired
	private MarksService service;

	@GetMapping("/all")
	public List<Marks> getAll() {
		log.info("START");
		log.info("END");
		return service.getAllMarks();
	}

	@GetMapping(value = "/{id}")
	public Marks getMarksById(@PathVariable("id") int id) throws MarksNotFoundException {
		log.info("START");
		Optional<Marks> std = service.findById(id);
		if (!std.isPresent()) {
			throw new MarksNotFoundException("Marks for Student with " + id + " is Not Found!");
		}
		Marks m = std.get();
		log.info("END");
		return m;
	}

	@PostMapping("/add")
	public String addMarks(@RequestBody Marks m) {
		log.info("START");
		log.info("END");
		service.save(m);
		return "Success";
	}
}
