package com.cognizant.repository;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.cognizant.model.Marks;
@Repository
public interface MarksRepository extends JpaRepository<Marks, Integer> {
	Optional<Marks> findById(String id);
}
